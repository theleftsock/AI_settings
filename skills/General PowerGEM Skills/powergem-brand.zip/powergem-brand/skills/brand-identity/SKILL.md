---
name: brand-identity
description: >
  PowerGEM brand identity and style guide. This skill should be used whenever
  creating any output — documents, presentations, spreadsheets, PDFs, HTML pages,
  React components, emails, sales assets, landing pages, one-pagers, workflow demos,
  internal communications, or any visual collateral. Triggers on "create", "build",
  "make", "draft", "write", "design", "generate", or any output-producing task.
  Always apply PowerGEM brand colors, typography, and voice standards.
version: 1.0.0
---

# PowerGEM Brand Identity

Apply these standards to ALL outputs. No exceptions.

## Company

- **Name**: PowerGEM (stylized as POWER**GEM** — "POWER" in regular weight, "GEM" in bold)
- **Domain**: power-gem.com
- **Industry**: Energy / Power Systems Software
- **Products**: TARA, SERVM, PROBE

## Color Palette

### Primary Colors

| Name        | HEX     | RGB           |
|-------------|---------|---------------|
| White       | #FFFFFF | 255, 255, 255 |
| Bright Gray | #EAE9E9 | 234, 233, 233 |
| Black       | #231F20 | 35, 31, 32    |

### Secondary Colors

| Name                | HEX     | RGB         |
|---------------------|---------|-------------|
| PowerGEM Green      | #338956 | 51, 137, 86 |
| PowerGEM Dark Green | #12493C | 18, 73, 60  |
| Midnight Green      | #023B37 | 2, 59, 55   |
| Eerie Black         | #081C1A | 8, 28, 26   |

### Highlight Colors

| Name          | HEX     | RGB           |
|---------------|---------|---------------|
| Green Yellow  | #D5E044 | 213, 224, 68  |
| Yellow Orange | #EC8022 | 236, 128, 34  |
| Metallic Blue | #275A74 | 39, 90, 116   |

### Color Usage Rules

- Text on colored backgrounds: **only black (#231F20) or white (#FFFFFF)** for accessibility
- Primary brand accent: PowerGEM Green (#338956)
- Dark backgrounds: Midnight Green (#023B37) or Eerie Black (#081C1A)
- Call-to-action / emphasis: Yellow Orange (#EC8022)
- Data visualization rotation: PowerGEM Green, Yellow Orange, Metallic Blue, Green Yellow
- Light backgrounds: White (#FFFFFF) or Bright Gray (#EAE9E9)

## Voice & Tone

- Professional and authoritative — trusted expert in energy systems
- Technical but accessible — clear explanations of complex concepts
- Confident — data-driven, evidence-based
- Consultative — focus on solving problems, not just listing features

## Output-Specific Rules

Refer to `references/output-formats.md` for detailed format-by-format styling rules (HTML, PPTX, DOCX, XLSX, PDF, sales assets, emails, internal comms).

Refer to `references/css-variables.md` for copy-paste CSS variables for HTML and React outputs.
