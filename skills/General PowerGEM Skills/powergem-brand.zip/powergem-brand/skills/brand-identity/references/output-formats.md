# Output Format Styling Rules

Detailed PowerGEM brand application rules for every output type.

---

## HTML / React Artifacts

### CSS Variables

Always include these CSS custom properties in HTML and React outputs:

```css
:root {
    /* Primary */
    --pg-white: #FFFFFF;
    --pg-bright-gray: #EAE9E9;
    --pg-black: #231F20;

    /* Secondary */
    --pg-green: #338956;
    --pg-dark-green: #12493C;
    --pg-midnight-green: #023B37;
    --pg-eerie-black: #081C1A;

    /* Highlight */
    --pg-green-yellow: #D5E044;
    --pg-yellow-orange: #EC8022;
    --pg-metallic-blue: #275A74;

    /* Semantic mapping */
    --brand-primary: #338956;
    --brand-secondary: #12493C;
    --brand-accent: #EC8022;
    --brand-dark: #023B37;
    --brand-light: #EAE9E9;
    --brand-text-dark: #231F20;
    --brand-text-light: #FFFFFF;
    --brand-highlight: #D5E044;
    --brand-info: #275A74;

    /* For rgba() usage */
    --brand-primary-rgb: 51, 137, 86;
    --brand-accent-rgb: 236, 128, 34;
    --brand-dark-rgb: 2, 59, 55;
}
```

### Element Styling

| Element | Style |
|---------|-------|
| Header / Nav | Background: PowerGEM Dark Green (#12493C) or Midnight Green (#023B37), white text |
| Primary buttons | Background: PowerGEM Green (#338956), white text |
| Secondary buttons | Transparent with PowerGEM Green (#338956) border |
| CTA / Accent buttons | Background: Yellow Orange (#EC8022), white text |
| Card backgrounds | White (#FFFFFF) or Bright Gray (#EAE9E9) |
| Footer | Background: Eerie Black (#081C1A) or Midnight Green (#023B37), white text |
| Links | PowerGEM Green (#338956) or Metallic Blue (#275A74) |
| Borders / dividers | Bright Gray (#EAE9E9) |

---

## Presentations (PPTX)

| Element | Style |
|---------|-------|
| Title slides | Background: Midnight Green (#023B37), white text |
| Content slides | Background: White, text: Black (#231F20) |
| Accent bars / shapes | PowerGEM Green (#338956) |
| Section dividers | Background: PowerGEM Dark Green (#12493C), white text |
| Charts | Color rotation: PowerGEM Green, Yellow Orange, Metallic Blue, Green Yellow |
| Bullet markers | PowerGEM Green (#338956) |
| Slide numbers / footers | Bright Gray (#EAE9E9) text on white, or white on dark backgrounds |

---

## Word Documents (DOCX)

| Element | Style |
|---------|-------|
| Heading 1 | PowerGEM Dark Green (#12493C), bold |
| Heading 2 | PowerGEM Green (#338956), bold |
| Heading 3 | Midnight Green (#023B37) |
| Body text | Black (#231F20) |
| Accent lines / borders | PowerGEM Green (#338956) |
| Table headers | Background: PowerGEM Green (#338956), white bold text |
| Table alternating rows | White / Bright Gray (#EAE9E9) |
| Callout / highlights | Yellow Orange (#EC8022) |
| Hyperlinks | Metallic Blue (#275A74) |

---

## Spreadsheets (XLSX)

| Element | Style |
|---------|-------|
| Header row | Background: PowerGEM Green (#338956), white bold text |
| Alternating rows | White / Bright Gray (#EAE9E9) |
| Totals row | Background: PowerGEM Dark Green (#12493C), white bold text |
| Chart colors | Rotation: PowerGEM Green, Yellow Orange, Metallic Blue, Green Yellow |
| Cell borders | Bright Gray (#EAE9E9) |
| Conditional formatting positive | PowerGEM Green (#338956) |
| Conditional formatting negative | Yellow Orange (#EC8022) |

---

## PDFs

| Element | Style |
|---------|-------|
| Header bar | Midnight Green (#023B37) |
| Section headings | PowerGEM Dark Green (#12493C) |
| Body text | Black (#231F20) |
| Accent elements | PowerGEM Green (#338956) |
| Callout boxes | Background: Bright Gray (#EAE9E9), left border: PowerGEM Green (#338956) |
| Page footer | Bright Gray (#EAE9E9) bar with Black text |

---

## Sales Assets (Landing Pages, One-Pagers, Workflow Demos)

Override any generic or dark theme defaults with PowerGEM brand:

| Element | Style |
|---------|-------|
| Primary accent | PowerGEM Green (#338956) |
| Secondary accent | Yellow Orange (#EC8022) |
| Dark sections | Midnight Green (#023B37) or Eerie Black (#081C1A) |
| Node / component borders | PowerGEM Green (#338956) |
| Active / highlighted nodes | Glow: rgba(51, 137, 86, 0.3) |
| CTA buttons | Yellow Orange (#EC8022), white text |
| Status: success | PowerGEM Green (#338956) |
| Status: warning | Yellow Orange (#EC8022) |
| Status: info | Metallic Blue (#275A74) |

When building assets for prospects, use the prospect's brand as primary and PowerGEM as secondary/co-branding.

---

## Email / Outreach

| Element | Style |
|---------|-------|
| Signature accent | PowerGEM Green (#338956) |
| Links | PowerGEM Green (#338956) or Metallic Blue (#275A74) |
| Headers | PowerGEM Dark Green (#12493C) |
| CTA buttons | Yellow Orange (#EC8022) |

---

## Internal Communications

| Element | Style |
|---------|-------|
| Section headers | PowerGEM Dark Green (#12493C) |
| Status: on track | PowerGEM Green (#338956) |
| Status: at risk | Yellow Orange (#EC8022) |
| Status: blocked | Standard red (#DC3545) |
| Dividers | Bright Gray (#EAE9E9) |

---

## Data Visualization (All Formats)

Standard color rotation for charts, graphs, and diagrams:

1. PowerGEM Green (#338956)
2. Yellow Orange (#EC8022)
3. Metallic Blue (#275A74)
4. Green Yellow (#D5E044)
5. PowerGEM Dark Green (#12493C)
6. Midnight Green (#023B37)

Use this order consistently across all chart types. For two-color charts, use PowerGEM Green + Yellow Orange.
