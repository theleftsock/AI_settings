# PowerGEM CSS Variables

Copy-paste ready CSS custom properties for HTML and React outputs.

## Full Variable Set

```css
:root {
    /* === Primary Colors === */
    --pg-white: #FFFFFF;
    --pg-bright-gray: #EAE9E9;
    --pg-black: #231F20;

    /* === Secondary Colors === */
    --pg-green: #338956;
    --pg-dark-green: #12493C;
    --pg-midnight-green: #023B37;
    --pg-eerie-black: #081C1A;

    /* === Highlight Colors === */
    --pg-green-yellow: #D5E044;
    --pg-yellow-orange: #EC8022;
    --pg-metallic-blue: #275A74;

    /* === Semantic Mapping === */
    --brand-primary: var(--pg-green);
    --brand-secondary: var(--pg-dark-green);
    --brand-accent: var(--pg-yellow-orange);
    --brand-dark: var(--pg-midnight-green);
    --brand-darker: var(--pg-eerie-black);
    --brand-light: var(--pg-bright-gray);
    --brand-text-dark: var(--pg-black);
    --brand-text-light: var(--pg-white);
    --brand-highlight: var(--pg-green-yellow);
    --brand-info: var(--pg-metallic-blue);

    /* === RGB Values (for rgba() usage) === */
    --pg-green-rgb: 51, 137, 86;
    --pg-dark-green-rgb: 18, 73, 60;
    --pg-midnight-green-rgb: 2, 59, 55;
    --pg-eerie-black-rgb: 8, 28, 26;
    --pg-yellow-orange-rgb: 236, 128, 34;
    --pg-metallic-blue-rgb: 39, 90, 116;
    --pg-green-yellow-rgb: 213, 224, 68;
    --pg-black-rgb: 35, 31, 32;

    /* === Status Colors === */
    --status-success: var(--pg-green);
    --status-warning: var(--pg-yellow-orange);
    --status-info: var(--pg-metallic-blue);
    --status-error: #DC3545;

    /* === Chart Colors (in rotation order) === */
    --chart-1: var(--pg-green);
    --chart-2: var(--pg-yellow-orange);
    --chart-3: var(--pg-metallic-blue);
    --chart-4: var(--pg-green-yellow);
    --chart-5: var(--pg-dark-green);
    --chart-6: var(--pg-midnight-green);
}
```

## Dark Theme Override

For dark-themed pages or sections:

```css
.dark-theme, [data-theme="dark"] {
    --bg-primary: var(--pg-eerie-black);
    --bg-elevated: var(--pg-midnight-green);
    --bg-surface: var(--pg-dark-green);
    --text-primary: var(--pg-white);
    --text-secondary: rgba(255, 255, 255, 0.7);
    --text-muted: rgba(255, 255, 255, 0.5);
    --accent: var(--pg-green);
    --accent-glow: rgba(var(--pg-green-rgb), 0.3);
}
```

## PANTONE & CMYK Reference

For print-ready outputs:

| Name                | HEX     | CMYK            | PANTONE         |
|---------------------|---------|-----------------|-----------------|
| White               | #FFFFFF | 0, 0, 0, 0     | —               |
| Bright Gray         | #EAE9E9 | 75, 5, 5, 0    | 663 C           |
| Black               | #231F20 | 0, 0, 0, 100   | Neutral Black C |
| PowerGEM Green      | #338956 | 80, 24, 83, 9  | 7740 C          |
| PowerGEM Dark Green | #12493C | 87, 46, 73, 46 | 3435 C          |
| Midnight Green      | #023B37 | 90, 53, 67, 55 | 3308 C          |
| Eerie Black         | #081C1A | 82, 62, 67, 78 | 6 C             |
| Green Yellow        | #D5E044 | 20, 0, 89, 0   | 380 C           |
| Yellow Orange       | #EC8022 | 0, 46, 86, 8   | 158 C           |
| Metallic Blue       | #275A74 | 88, 59, 38, 17 | 7700 C          |
