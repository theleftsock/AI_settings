# PowerGEM Brand Plugin

Enforces PowerGEM brand identity across all outputs — documents, presentations, spreadsheets, PDFs, HTML, React, sales assets, emails, and internal communications.

## What it does

When installed, this plugin ensures every piece of collateral Claude produces uses the official PowerGEM color palette, typography, and voice guidelines from the Style Guide v4.

A session hook reminds Claude of brand requirements at the start of every conversation. The brand-identity skill provides the full color palette, usage rules, and format-specific styling for every output type.

## Components

| Component | Name | Purpose |
|-----------|------|---------|
| Skill | brand-identity | Full brand guide — colors, voice, per-format styling rules |
| Hook | SessionStart | Loads brand context at session start |

## Color Palette (Quick Reference)

**Primary**: White (#FFFFFF), Bright Gray (#EAE9E9), Black (#231F20)

**Secondary**: PowerGEM Green (#338956), Dark Green (#12493C), Midnight Green (#023B37), Eerie Black (#081C1A)

**Highlight**: Green Yellow (#D5E044), Yellow Orange (#EC8022), Metallic Blue (#275A74)

## Setup

Install the plugin — no configuration needed. Brand standards apply automatically to all sessions.
